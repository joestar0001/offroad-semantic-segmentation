
# Semantic Segmentation Model — Hackathon Submission

## Overview
Transformer-based semantic segmentation model using DINOv2 backbone trained for pixel-wise classification of off-road scenes.

## Metrics
Mean IoU: 0.3185  
Dice Score: 0.4385  
Pixel Accuracy: 0.7025  

## Run Inference
python test_segmentation.py --model_path segmentation_head.pth --data_dir <images>

## Notes
Model shows stable convergence and generalizes well. Limitations include small-object segmentation and boundary precision.
